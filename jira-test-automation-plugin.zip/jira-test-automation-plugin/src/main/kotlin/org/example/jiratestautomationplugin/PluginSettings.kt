package org.example.jiratestautomationplugin

import com.intellij.openapi.application.PathManager
import java.io.File
import java.util.*

object PluginSettings {
    private const val JIRA_URL = "jiraUrl"
    private const val PROJECT_KEY = "projectKey"
    private const val EMAIL = "email"
    private const val API_TOKEN = "apiToken"
    private const val USE_OAUTH = "useOAuth"
    private const val SELECTED_RESOURCE = "selectedResource"

    private val properties = Properties()
    private val configFile: File
        get() = File(PathManager.getConfigPath(), "jira_plugin.properties")

    init {
        if (configFile.exists()) {
            configFile.inputStream().use { properties.load(it) }
        }
    }

    fun saveSettings(jiraUrl: String, projectKey: String, email: String, apiToken: String, useOAuth: Boolean, selectedResource: String? = null) {
        properties[JIRA_URL] = jiraUrl
        properties[PROJECT_KEY] = projectKey
        properties[EMAIL] = email
        properties[API_TOKEN] = apiToken
        properties[USE_OAUTH] = useOAuth.toString()
        selectedResource?.let { properties[SELECTED_RESOURCE] = it }

        configFile.outputStream().use { properties.store(it, "Jira Plugin Settings") }
    }

    val jiraUrl: String?
        get() = properties.getProperty(JIRA_URL)

    val projectKey: String?
        get() = properties.getProperty(PROJECT_KEY)

    val email: String?
        get() = properties.getProperty(EMAIL)

    val apiToken: String?
        get() = properties.getProperty(API_TOKEN)

    val useOAuth: Boolean
        get() = properties.getProperty(USE_OAUTH, "false").toBoolean()

    val selectedResource: String?
        get() = properties.getProperty(SELECTED_RESOURCE)

    val areSettingsConfigured: Boolean
        get() {
            return if (useOAuth) {
                !jiraUrl.isNullOrEmpty() && !projectKey.isNullOrEmpty()
            } else {
                !jiraUrl.isNullOrEmpty() && !projectKey.isNullOrEmpty() &&
                        !email.isNullOrEmpty() && !apiToken.isNullOrEmpty()
            }
        }
}