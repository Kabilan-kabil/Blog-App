package org.example.jiratestautomationplugin.ui

import org.example.jiratestautomationplugin.persistence.AnalyticsStats
import org.example.jiratestautomationplugin.persistence.DatabaseManager
import org.example.jiratestautomationplugin.persistence.PassFailData
import org.example.jiratestautomationplugin.persistence.TicketTypeData
import com.intellij.openapi.application.ApplicationManager
import com.intellij.openapi.ui.SimpleToolWindowPanel
import com.intellij.ui.JBColor
import com.intellij.ui.components.JBLabel
import com.intellij.ui.components.JBPanel
import com.intellij.util.ui.JBUI
import java.awt.*
import javax.swing.*
import kotlin.math.roundToInt

class AnalyticsPanel(private val project: com.intellij.openapi.project.Project) : SimpleToolWindowPanel(false, true) {
    private val mainPanel = JBPanel<JBPanel<*>>(BorderLayout())

    init {
        setContent(mainPanel)
        refresh()
    }

    fun refresh() {
        showLoading()
        loadAnalyticsData()
    }

    private fun showLoading() {
        mainPanel.removeAll()
        mainPanel.add(JBLabel("Loading analytics data...", SwingConstants.CENTER), BorderLayout.CENTER)
        mainPanel.revalidate()
        mainPanel.repaint()
    }

    private fun loadAnalyticsData() {
        ApplicationManager.getApplication().executeOnPooledThread {
            try {
                val stats = DatabaseManager.getAnalyticsStats()
                val passFailData = DatabaseManager.getPassFailData()
                val ticketData = DatabaseManager.getTicketTypeData()

                SwingUtilities.invokeLater {
                    buildUi(stats, passFailData, ticketData)
                }
            } catch (e: Exception) {
                SwingUtilities.invokeLater {
                    showError("Failed to load analytics: ${e.message}")
                }
            }
        }
    }

    private fun buildUi(stats: AnalyticsStats, passFailData: PassFailData, ticketData: TicketTypeData) {
        mainPanel.removeAll()
        mainPanel.layout = BorderLayout(0, JBUI.scale(10))
        mainPanel.border = JBUI.Borders.empty(10)

        val statsPanel = createStatsPanel(stats)
        val chartsPanel = createChartsPanel(passFailData, ticketData)

        mainPanel.add(statsPanel, BorderLayout.NORTH)
        mainPanel.add(chartsPanel, BorderLayout.CENTER)

        mainPanel.revalidate()
        mainPanel.repaint()
    }

    private fun createStatsPanel(stats: AnalyticsStats): JPanel {
        val panel = JPanel(GridLayout(2, 4, JBUI.scale(10), JBUI.scale(10)))
        panel.border = BorderFactory.createTitledBorder("Key Metrics")

        panel.add(createStatCard("Total Tests", stats.totalTests.toString()))
        panel.add(createStatCard("Passed", stats.passedTests.toString()))
        panel.add(createStatCard("Failed", stats.failedTests.toString()))
        panel.add(createStatCard("Success Rate", "${String.format("%.1f", stats.successRate)}%"))
        panel.add(createStatCard("Tickets Created", stats.ticketsCreated.toString()))
        panel.add(createStatCard("Critical Issues", stats.criticalIssues.toString()))
        panel.add(createStatCard("Avg Resolution Time", stats.avgResolutionTime))
        panel.add(createStatCard("Open Tickets", stats.openTickets.toString()))

        return panel
    }

    private fun createChartsPanel(passFailData: PassFailData, ticketData: TicketTypeData): JPanel {
        val panel = JPanel(GridLayout(1, 2, JBUI.scale(10), 0))

        val passFailChart = createPassFailChart(passFailData)
        val ticketDistributionChart = createTicketDistributionChart(ticketData)

        panel.add(passFailChart)
        panel.add(ticketDistributionChart)

        return panel
    }

    private fun createPassFailChart(data: PassFailData): JPanel {
        val panel = BarChartPanel(
            data.dates,
            listOf(data.passed, data.failed),
            listOf(JBColor(0x4CAF50, 0x388E3C), JBColor(0xF44336, 0xD32F2F)),
            "Test Results Over Time"
        )
        return panel
    }

    private fun createTicketDistributionChart(data: TicketTypeData): JPanel {
        val panel = JPanel(GridLayout(data.labels.size, 1, 0, JBUI.scale(5)))
        panel.border = BorderFactory.createTitledBorder("Ticket Severity Distribution")

        val total = data.values.sum().toDouble()
        if (total == 0.0) {
            panel.layout = BorderLayout()
            panel.add(JBLabel("No ticket data available.", SwingConstants.CENTER), BorderLayout.CENTER)
            return panel
        }

        val colors = listOf(JBColor.RED, JBColor.ORANGE, JBColor.YELLOW, JBColor.GREEN, JBColor.CYAN)

        data.labels.forEachIndexed { index, label ->
            val value = data.values[index]
            val percentage = (value / total) * 100
            panel.add(createProgressBar(label, value, percentage, colors[index % colors.size]))
        }

        return panel
    }
    
    private fun createProgressBar(label: String, value: Int, percentage: Double, color: Color): JPanel {
        val panel = JPanel(BorderLayout(JBUI.scale(5), 0))
        panel.add(JBLabel("$label ($value)"), BorderLayout.WEST)

        val progressBar = JProgressBar(0, 100).apply {
            this.value = percentage.roundToInt()
            isStringPainted = true
            string = "${String.format("%.1f", percentage)}%"
            foreground = color
        }
        panel.add(progressBar, BorderLayout.CENTER)
        return panel
    }

    private fun createStatCard(title: String, value: String): JPanel {
        val panel = JPanel(BorderLayout())
        panel.border = BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(JBColor.border()),
            JBUI.Borders.empty(5)
        )

        val titleLabel = JBLabel(title, SwingConstants.CENTER)
        val valueLabel = JBLabel(value, SwingConstants.CENTER)
        valueLabel.font = valueLabel.font.deriveFont(Font.BOLD, 18f)

        panel.add(titleLabel, BorderLayout.NORTH)
        panel.add(valueLabel, BorderLayout.CENTER)

        return panel
    }

    private fun showError(message: String) {
        mainPanel.removeAll()
        mainPanel.add(JBLabel("Error: $message", SwingConstants.CENTER), BorderLayout.CENTER)
        mainPanel.revalidate()
        mainPanel.repaint()
    }
}

// A simple custom panel to draw a bar chart
private class BarChartPanel(
    private val labels: List<String>,
    private val values: List<List<Int>>,
    private val colors: List<Color>,
    private val title: String
) : JPanel() {

    init {
        border = BorderFactory.createTitledBorder(title)
    }

    override fun paintComponent(g: Graphics) {
        super.paintComponent(g)

        val g2d = g as Graphics2D
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON)

        val width = width
        val height = height
        val padding = JBUI.scale(20)
        val labelPadding = JBUI.scale(30)
        val chartWidth = width - 2 * padding
        val chartHeight = height - 2 * padding - labelPadding

        if (labels.isEmpty()) {
            g2d.drawString("No data available.", width / 2 - 50, height / 2)
            return
        }

        val maxValue = values.maxOfOrNull { it.maxOrNull() ?: 0 } ?: 0
        if (maxValue == 0) {
            g2d.drawString("No data available.", width / 2 - 50, height / 2)
            return
        }

        val barWidth = chartWidth / (labels.size * values.size)

        for (i in labels.indices) {
            for (j in values.indices) {
                val barHeight = (values[j][i].toDouble() / maxValue * chartHeight).toInt()
                val x = padding + i * (chartWidth / labels.size) + j * barWidth
                val y = height - padding - labelPadding - barHeight
                g2d.color = colors[j]
                g2d.fillRect(x, y, barWidth, barHeight)
            }
            g2d.color = JBColor.foreground()
            val labelX = padding + i * (chartWidth / labels.size) + (chartWidth / labels.size) / 2 - g.fontMetrics.stringWidth(labels[i]) / 2
            g2d.drawString(labels[i], labelX, height - padding)
        }
    }
}