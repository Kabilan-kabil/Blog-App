package org.example.jiratestautomationplugin

import com.intellij.ui.components.JBPasswordField
import com.intellij.ui.components.JBTextField
import com.intellij.ui.dsl.builder.panel
import javax.swing.JCheckBox
import javax.swing.JPanel

class PluginSettingsPanel {

    private val jiraUrlField = JBTextField()
    private val projectKeyField = JBTextField()
    private val emailField = JBTextField()
    private val apiTokenField = JBPasswordField()
    private val useOAuthCheckBox = JCheckBox("Use OAuth 2.0")

    val panel: JPanel = panel {
        row("Jira URL:") {
            cell(jiraUrlField)
        }
        row("Project Key:") {
            cell(projectKeyField)
        }
        row("Email:") {
            cell(emailField)
        }
        row("API Token:") {
            cell(apiTokenField)
        }
        row {
            cell(useOAuthCheckBox)
        }
    }

    init {
        loadSettings()
    }

    private fun loadSettings() {
        jiraUrlField.text = PluginSettings.jiraUrl
        projectKeyField.text = PluginSettings.projectKey
        emailField.text = PluginSettings.email
        apiTokenField.text = PluginSettings.apiToken
        useOAuthCheckBox.isSelected = PluginSettings.useOAuth
    }

    fun isModified(): Boolean {
        return jiraUrlField.text != PluginSettings.jiraUrl ||
                projectKeyField.text != PluginSettings.projectKey ||
                emailField.text != PluginSettings.email ||
                String(apiTokenField.password) != PluginSettings.apiToken ||
                useOAuthCheckBox.isSelected != PluginSettings.useOAuth
    }

    fun apply() {
        PluginSettings.saveSettings(
            jiraUrlField.text,
            projectKeyField.text,
            emailField.text,
            String(apiTokenField.password),
            useOAuthCheckBox.isSelected
        )
    }

    fun reset() {
        loadSettings()
    }
}
