package org.example.jiratestautomationplugin.ui

import com.intellij.openapi.ui.DialogWrapper
import com.intellij.ui.JBColor
import java.awt.BorderLayout
import java.awt.Dimension
import java.awt.FlowLayout
import java.awt.Font
import javax.swing.JComponent
import javax.swing.JLabel
import javax.swing.JPanel
import javax.swing.JScrollPane
import javax.swing.JTextArea

class ApprovalDialog(
    private val testName: String,
    private val errorMessage: String,
    private val stackTrace: String,
    private val severity: String? = null,
    private val probableCause: String? = null,
    private val isClustered: Boolean = false,
    private val clusterInfo: String? = null
) : DialogWrapper(true) {
    var isApproved = false

    init {
        init()
        title = "Create Jira Ticket for Test Failure"
        setOKButtonText("Create Ticket")
        setCancelButtonText("Cancel")
    }

    override fun createCenterPanel(): JComponent {
        val panel = JPanel(BorderLayout(5, 5))
        val infoPanel = JPanel(FlowLayout(FlowLayout.LEFT))

        severity?.let {
            val color = when (it.toLowerCase()) {
                "critical" -> JBColor.RED
                "major" -> JBColor.ORANGE
                else -> JBColor.YELLOW
            }
            val severityLabel = JLabel("Severity: $it").apply {
                foreground = color
                font = font.deriveFont(Font.BOLD)
            }
            infoPanel.add(severityLabel)
        }

        if (isClustered && clusterInfo != null) {
            val clusterLabel = JLabel("⚠️ $clusterInfo").apply {
                foreground = JBColor.BLUE
                font = font.deriveFont(Font.BOLD)
            }
            infoPanel.add(clusterLabel)
        }

        panel.add(infoPanel, BorderLayout.NORTH)

        val contentPanel = JPanel(BorderLayout(5, 5))
        probableCause?.let { cause ->
            val causeArea = JTextArea("Probable cause: $cause").apply {
                isEditable = false
                lineWrap = true
                wrapStyleWord = true
                background = panel.background
                border = null
            }
            contentPanel.add(causeArea, BorderLayout.NORTH)
        }

        val errorDetails = JTextArea("Test: $testName\n\nError: $errorMessage\n\nStack Trace:\n$stackTrace").apply {
            isEditable = false
            lineWrap = true
            wrapStyleWord = true
        }

        val scrollPane = JScrollPane(errorDetails).apply {
            preferredSize = Dimension(600, 300)
        }
        contentPanel.add(scrollPane, BorderLayout.CENTER)
        panel.add(contentPanel, BorderLayout.CENTER)

        return panel
    }

    override fun doOKAction() {
        isApproved = true
        super.doOKAction()
    }
}