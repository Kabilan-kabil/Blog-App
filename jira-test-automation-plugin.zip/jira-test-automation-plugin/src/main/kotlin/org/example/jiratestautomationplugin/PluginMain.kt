package org.example.jiratestautomationplugin


import com.cts.jiraplugin.core.TestFailureDetector
import com.cts.jiraplugin.persistence.DatabaseManager
import com.intellij.openapi.components.BaseComponent
import com.intellij.openapi.project.Project
import com.intellij.openapi.project.ProjectManager
import com.intellij.openapi.project.ProjectManagerListener
import com.intellij.openapi.startup.StartupActivity

class PluginMain : BaseComponent {
    companion object {
        const val PLUGIN_ID = "com.cts.jira-test-automation-plugin"
    }

    override fun initComponent() {
        // Initialize application-level components
        DatabaseManager.initializeDatabase()
        DatabaseManager.ensureTestRunsTable()
        DatabaseManager.ensureJiraTicketsEnhanced()
    }

    override fun disposeComponent() {
        // Clean up application-level resources
    }
}

class PluginStartupActivity : StartupActivity {
    override fun runActivity(project: Project) {
        // Initialize project-level components
        TestFailureDetector.startMonitoring(project)

        // Add a listener to stop monitoring when the project is closed
        project.messageBus.connect().subscribe(ProjectManager.TOPIC, object : ProjectManagerListener {
            override fun projectClosing(p: Project) {
                if (p == project) {
                    TestFailureDetector.stopMonitoring(p)
                }
            }
        })
    }
}
