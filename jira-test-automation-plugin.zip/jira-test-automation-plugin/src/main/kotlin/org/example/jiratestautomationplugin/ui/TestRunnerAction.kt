package org.example.jiratestautomationplugin.ui

import com.intellij.openapi.actionSystem.AnAction
import com.intellij.openapi.actionSystem.AnActionEvent
import org.example.jiratestautomationplugin.core.TestFailureDetector
import org.example.jiratestautomationplugin.core.TestDataGenerator

// Action to run all test cases
@Suppress("unused")
class RunAllTestsAction : AnAction("Run All Test Cases") {
    override fun actionPerformed(e: AnActionEvent) {
        TestFailureDetector.runAllTestCases()
    }
}

@Suppress("unused")
class RunSingleTestAction : AnAction("Run Single Test Case") {
    override fun actionPerformed(e: AnActionEvent) {
        val testFailure = TestDataGenerator.generateTestFailure()
        // Access the properties of the Triple
        TestFailureDetector.onTestFailure(
            testName = testFailure.first,
            errorMessage = testFailure.second,
            stackTrace = testFailure.third
        )
    }
}
