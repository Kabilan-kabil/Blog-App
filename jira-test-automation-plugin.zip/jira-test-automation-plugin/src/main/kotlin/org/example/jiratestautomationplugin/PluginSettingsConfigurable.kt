package org.example.jiratestautomationplugin

import com.intellij.openapi.options.Configurable
import javax.swing.JComponent

class PluginSettingsConfigurable : Configurable {

    private var settingsPanel: PluginSettingsPanel? = null

    override fun getDisplayName(): String {
        return "Jira Test Automation Plugin"
    }

    override fun createComponent(): JComponent? {
        settingsPanel = PluginSettingsPanel()
        return settingsPanel?.panel
    }

    override fun isModified(): Boolean {
        return settingsPanel?.isModified() ?: false
    }

    override fun apply() {
        settingsPanel?.apply()
    }

    override fun reset() {
        settingsPanel?.reset()
    }

    override fun disposeUIResources() {
        settingsPanel = null
    }
}
