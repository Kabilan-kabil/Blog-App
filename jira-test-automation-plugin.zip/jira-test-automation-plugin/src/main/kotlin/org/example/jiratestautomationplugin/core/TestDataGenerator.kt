package org.example.jiratestautomationplugin.core

object TestDataGenerator {
    private val testFailures = listOf(
        Triple(
            "UserRegistrationTest.testNewUserCreation",
            "NullPointerException: Cannot read property 'firstName' of null",
            """
                at UserRegistrationTest.testNewUserCreation(UserRegistrationTest.java:42)
                at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
                at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
            """.trimIndent()
        ),
        Triple(
            "PaymentServiceTest.testPaymentProcessing",
            "TimeoutException: Request timed out after 5000ms",
            """
                at PaymentServiceTest.testPaymentProcessing(PaymentServiceTest.java:87)
                at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
            """.trimIndent()
        ),
        Triple(
            "DatabaseConnectionTest.testConnectionPool",
            "SQLException: Connection refused. Check that the hostname and port are correct",
            """
                at DatabaseConnectionTest.testConnectionPool(DatabaseConnectionTest.java:23)
                at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
            """.trimIndent()
        ),
        Triple(
            "ShoppingCartTest.testAddItemToCart",
            "AssertionError: Expected 2 but found 1",
            """
                at ShoppingCartTest.testAddItemToCart(ShoppingCartTest.java:56)
                at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
            """.trimIndent()
        ),
        Triple(
            "AuthenticationTest.testLoginWithInvalidCredentials",
            "SecurityException: Invalid authentication token",
            """
                at AuthenticationTest.testLoginWithInvalidCredentials(AuthenticationTest.java:34)
                at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
            """.trimIndent()
        )
    )

    fun generateTestFailure(): Triple<String, String, String> {
        return testFailures.random()
    }

    fun getAllTestFailures(): List<Triple<String, String, String>> {
        return testFailures
    }
}