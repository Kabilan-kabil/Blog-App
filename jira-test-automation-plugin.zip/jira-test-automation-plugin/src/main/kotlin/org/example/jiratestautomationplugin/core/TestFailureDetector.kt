package org.example.jiratestautomationplugin.core

import org.example.jiratestautomationplugin.PluginSettings
import org.example.jiratestautomationplugin.persistence.DatabaseManager
import com.intellij.execution.testframework.sm.runner.SMTRunnerEventsListener
import com.intellij.execution.testframework.sm.runner.SMTestProxy
import com.intellij.openapi.diagnostic.Logger
import com.intellij.openapi.project.Project
import com.intellij.openapi.ui.Messages
import com.intellij.util.messages.MessageBusConnection
import java.util.concurrent.ConcurrentHashMap

class TestFailureDetector {
    companion object {
        private val logger = Logger.getInstance(TestFailureDetector::class.java)
        private val connections = ConcurrentHashMap<Project, MessageBusConnection>()

        fun startMonitoring(project: Project) {
            if (connections.containsKey(project)) {
                return
            }
            val connection = project.messageBus.connect()
            connections[project] = connection

            connection.subscribe(SMTRunnerEventsListener.TOPIC, object : SMTRunnerEventsListener {
                override fun onTestFailed(testProxy: SMTestProxy) {
                    super.onTestFailed(testProxy)
                    if (!testProxy.isLeaf) {
                        return
                    }
                    // This is the sole entry point for new failures
                    onNewFailureDetected(
                        testProxy.name,
                        testProxy.errorMessage ?: "No error message",
                        testProxy.stacktrace ?: "No stack trace"
                    )
                }
            })
            logger.info("Started monitoring test failures for project: ${project.name}")
        }

        fun stopMonitoring(project: Project) {
            connections.remove(project)?.disconnect()
            logger.info("Stopped monitoring test failures for project: ${project.name}")
        }

        // This method's only job is to process a new failure.
        fun onNewFailureDetected(testName: String, errorMessage: String, stackTrace: String) {
            // 1. Analyze the failure to get embedding and other details.
            val aiResult = AIClient.analyzeFailure(testName, errorMessage, stackTrace)

            // 2. Store the failure in the database. The UI will pick it up on the next refresh.
            DatabaseManager.storeFailureWithEmbedding(
                testName = testName,
                errorMessage = errorMessage,
                stackTrace = stackTrace,
                embedding = aiResult?.embedding ?: emptyList(),
                severity = aiResult?.severity,
                probableCause = aiResult?.probableCause
            )
        }

        // This method is now internal and can be called from the UI
        internal fun createJiraTicketForCluster(cluster: FailureCluster, representativeResult: AIAnalysisResult?) {
            val settings = PluginSettings
            if (!settings.areSettingsConfigured) {
                Messages.showErrorDialog("Please configure Jira settings first", "Configuration Required")
                return
            }

            val summary = representativeResult?.summary ?: "Cluster of failures: ${cluster.representativeName}"
            val description = buildDescriptionForCluster(cluster, representativeResult)
            val issueType = when (representativeResult?.severity?.toLowerCase()) {
                "critical", "major" -> "Bug"
                else -> "Task"
            }

            val jiraClient = if (settings.useOAuth) JiraClient(settings.jiraUrl!!) else JiraClient(settings.jiraUrl!!, settings.email!!, settings.apiToken!!)
            val issueKey = jiraClient.createIssue(settings.projectKey!!, summary, description, issueType)

            issueKey?.let {
                val issueUrl = jiraClient.getIssueUrl(it)
                cluster.failures.forEach { failure ->
                    val name = failure["test_name"] as String
                    val error = failure["error_message"] as String
                    // Update the status for all failures in the cluster
                    DatabaseManager.updateFailureStatus(name, error, "Ticket Created")
                    // Also store a ticket link for each failure
                    DatabaseManager.storeTicket(name, it, issueUrl)
                }
                Messages.showInfoMessage("Jira ticket created for cluster: $it", "Success")
            }
        }

        // This method is now internal and can be called from the UI
        internal fun createJiraTicket(testName: String, errorMessage: String, stackTrace: String, aiResult: AIAnalysisResult?) {
            val settings = PluginSettings
            if (!settings.areSettingsConfigured) {
                Messages.showErrorDialog("Please configure Jira settings first", "Configuration Required")
                return
            }

            val summary = aiResult?.summary ?: "Test Failure: $testName"
            val description = buildDescription(errorMessage, stackTrace, aiResult)
            val issueType = when (aiResult?.severity?.toLowerCase()) {
                "critical", "major" -> "Bug"
                else -> "Task"
            }

            val jiraClient = if (settings.useOAuth) JiraClient(settings.jiraUrl!!) else JiraClient(settings.jiraUrl!!, settings.email!!, settings.apiToken!!)
            val issueKey = jiraClient.createIssue(settings.projectKey!!, summary, description, issueType)

            issueKey?.let {
                DatabaseManager.storeTicket(testName, it, jiraClient.getIssueUrl(it))
                DatabaseManager.updateFailureStatus(testName, errorMessage, "Ticket Created")
                Messages.showInfoMessage("Jira ticket created: $it", "Success")
            }
        }

        private fun buildDescription(errorMessage: String, stackTrace: String, aiResult: AIAnalysisResult?): String {
            val cause = aiResult?.probableCause?.let { "Probable Root Cause: $it\n\n" } ?: ""
            val severity = aiResult?.severity?.let { "Severity: $it\n\n" } ?: ""
            return "${severity}${cause}Test failed with error: $errorMessage\n\nStack trace:\n$stackTrace\n\n*AI-powered analysis by Jira Test Automation Plugin*"
        }

        private fun buildDescriptionForCluster(cluster: FailureCluster, representativeResult: AIAnalysisResult?): String {
            val cause = representativeResult?.probableCause?.let { "Probable Root Cause (for representative failure): $it\n\n" } ?: ""
            val severity = representativeResult?.severity?.let { "Severity: $it\n\n" } ?: ""
            val failureList = cluster.failures.joinToString("\n") { " - ${it["test_name"]}" }
            return "${severity}${cause}This ticket represents a cluster of ${cluster.count} similar test failures.\n\nAffected Tests:\n$failureList\n\nRepresentative Failure: ${cluster.representativeName}\nError: ${representativeResult?.summary}\n\n*AI-powered analysis by Jira Test Automation Plugin*"
        }
    }
}