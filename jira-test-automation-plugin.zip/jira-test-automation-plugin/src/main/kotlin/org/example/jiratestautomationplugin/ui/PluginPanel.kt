package org.example.jiratestautomationplugin.ui

import com.intellij.openapi.actionSystem.ActionManager
import com.intellij.openapi.actionSystem.ActionToolbar
import com.intellij.openapi.actionSystem.DefaultActionGroup
import com.intellij.openapi.project.Project
import com.intellij.openapi.ui.SimpleToolWindowPanel
import com.intellij.ui.components.JBScrollPane
import com.intellij.ui.table.JBTable
import org.example.jiratestautomationplugin.persistence.DatabaseManager
import java.awt.BorderLayout
import javax.swing.JPanel
import javax.swing.table.DefaultTableModel

class PluginPanel(project: Project) : SimpleToolWindowPanel(false, true) {
    private val table: JBTable
    private val tableModel: DefaultTableModel

    init {
        val toolbar = createToolbar()
        setToolbar(toolbar.component)

        tableModel = DefaultTableModel(arrayOf("Test Name", "Jira Key", "Jira URL", "Created At"), 0)
        table = JBTable(tableModel)
        table.setShowGrid(true)

        val scrollPane = JBScrollPane(table)
        add(scrollPane, BorderLayout.CENTER)

        refresh()
    }

    private fun createToolbar(): ActionToolbar {
        val actionGroup = DefaultActionGroup().apply {
            add(OpenSettingsAction())
            add(RefreshAction())
        }

        return ActionManager.getInstance().createActionToolbar("JiraPluginToolbar", actionGroup, false)
    }

    fun refresh() {
        // Clear existing data
        tableModel.rowCount = 0

        // Load tickets from database
        val tickets = DatabaseManager.getTickets()
        tickets.forEach { ticket ->
            tableModel.addRow(arrayOf(
                ticket.testName,
                ticket.jiraKey,
                ticket.jiraUrl,
                ticket.createdAt.toString()
            ))
        }
    }
}