package com.cts.jiraplugin.core

import com.intellij.notification.NotificationGroupManager
import com.intellij.notification.NotificationType
import com.intellij.openapi.project.Project
import com.intellij.openapi.ui.MessageType

object NotificationManager {
    private const val NOTIFICATION_GROUP = "Jira Test Automation Plugin"

    fun showBalloonWarning(project: Project?, message: String) {
        val notification = NotificationGroupManager.getInstance()
            .getNotificationGroup(NOTIFICATION_GROUP)
            .createNotification("Test Failure Detected", message, NotificationType.WARNING)

        notification.notify(project)
    }

    fun showBalloonInfo(project: Project?, message: String) {
        val notification = NotificationGroupManager.getInstance()
            .getNotificationGroup(NOTIFICATION_GROUP)
            .createNotification("Jira Ticket Created", message, NotificationType.INFORMATION)

        notification.notify(project)
    }

    fun showBalloonError(project: Project?, message: String) {
        val notification = NotificationGroupManager.getInstance()
            .getNotificationGroup(NOTIFICATION_GROUP)
            .createNotification("Plugin Error", message, NotificationType.ERROR)

        notification.notify(project)
    }
}