package com.cts.jiraplugin.core

import com.intellij.execution.testframework.sm.runner.events.TestFailedEvent
import com.intellij.execution.testframework.sm.runner.events.TestFinishedEvent
import com.intellij.openapi.application.ApplicationManager
import com.intellij.openapi.diagnostic.Logger
import com.intellij.openapi.ui.Messages
import com.cts.jiraplugin.PluginSettings
import com.cts.jiraplugin.persistence.DatabaseManager
import com.cts.jiraplugin.ui.ApprovalDialog

private const val TESTING_MODE = true

class TestFailureDetector {
    companion object {
        private val logger = Logger.getInstance(TestFailureDetector::class.java)

        fun startMonitoring() {
            // In a real implementation, we would register with the test framework
            // For MVP, we'll simulate this with a simple listener approach
            // Actual integration would depend on the test framework used
            println("Test failure monitoring started")
        }

        fun onTestFailure(testName: String, errorMessage: String, stackTrace: String) {
            // Get AI analysis first
            val aiResult = AIClient.analyzeFailure(testName, errorMessage, stackTrace)

            // Check for duplicates in our database
            val previousFailures = DatabaseManager.getRecentFailures(24) // Last 24 hours
            val isDuplicate = aiResult?.let { result ->
                AIClient.checkForDuplicates(result.embedding, previousFailures)
            } ?: false

            // Show approval dialog in UI thread
            ApplicationManager.getApplication().invokeLater {
                val dialog = ApprovalDialog(
                    testName,
                    errorMessage,
                    stackTrace,
                    aiResult?.severity,
                    aiResult?.probableCause,
                    isDuplicate
                )
                dialog.show()

                if (dialog.isApproved && !isDuplicate) {
                    createJiraTicket(testName, errorMessage, stackTrace, aiResult)
                } else if (isDuplicate) {
                    // Suggest linking to existing ticket
                    aiResult?.similarTicket?.let { similar ->
                        val option = Messages.showYesNoDialog(
                            "This failure appears similar to ${similar.jiraKey}. Would you like to view the existing ticket?",
                            "Possible Duplicate",
                            Messages.getQuestionIcon()
                        )
                        if (option == Messages.YES) {
                            // Open the existing ticket in browser
                            com.intellij.ide.BrowserUtil.browse(similar.jiraUrl)
                        }
                    }
                }
            }
        }

        private fun createJiraTicket(testName: String, errorMessage: String, stackTrace: String, aiResult: AIAnalysisResult?) {
            val settings = PluginSettings
            if (!settings.areSettingsConfigured) {
                Messages.showErrorDialog("Please configure Jira settings first", "Configuration Required")
                return
            }

            // Use AI-generated summary if available, otherwise fallback
            val summary = aiResult?.summary ?: "Test Failure: $testName"

            val jiraClient = JiraClient(
                settings.jiraUrl!!,
                settings.email!!,
                settings.apiToken!!
            )

            // Determine issue type based on severity
            val issueType = when (aiResult?.severity?.toLowerCase()) {
                "critical" -> "Bug"
                "major" -> "Bug"
                else -> "Task"
            }

            val issueKey = jiraClient.createIssue(
                settings.projectKey!!,
                summary,
                buildDescription(errorMessage, stackTrace, aiResult),
                issueType
            )

            issueKey?.let {
                DatabaseManager.storeTicket(testName, it, jiraClient.getIssueUrl(it))

                // Store the failure with embedding for future duplicate detection
                aiResult?.embedding?.let { embedding ->
                    DatabaseManager.storeFailureWithEmbedding(testName, errorMessage, embedding)
                }

                // Show success message
                Messages.showInfoMessage("Jira ticket created: $it", "Success")

                // Refresh plugin panel if visible
                ApplicationManager.getApplication().invokeLater {
                    // This would need to be implemented to refresh the UI
                    // PluginPanel.refresh()
                }
            }
        }

        private fun buildDescription(errorMessage: String, stackTrace: String, aiResult: AIAnalysisResult?): String {
            val probableCause = aiResult?.probableCause?.let {
                "Probable Root Cause: $it\n\n"
            } ?: ""

            val severity = aiResult?.severity?.let {
                "Severity: $it\n\n"
            } ?: ""

            return """
                $severity$probableCause
                Test failed with error: $errorMessage
                
                Stack trace:
                $stackTrace
                
                *AI-powered analysis by Jira Test Automation Plugin*
            """.trimIndent()
        }
        // Add this method to the TestFailureDetector companion object
        fun runAllTestCases() {
            val testCases = TestDataGenerator.getAllTestFailures()

            testCases.forEach { (testName, errorMessage, stackTrace) ->
                // Add a small delay between test cases to avoid UI issues
                try {
                    Thread.sleep(500)
                } catch (e: InterruptedException) {
                    Thread.currentThread().interrupt()
                }
                onTestFailure(testName, errorMessage, stackTrace)
            }
        }

        // Helper function to simulate test failures for development
        fun simulateTestFailure() {
            onTestFailure(
                "UserRegistrationTest.testNewUserCreation",
                "NullPointerException: Cannot read property 'firstName' of null",
                """
                    at UserRegistrationTest.testNewUserCreation(UserRegistrationTest.java:42)
                    at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
                    at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
                    at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
                    at java.base/java.lang.reflect.Method.invoke(Method.java:566)
                    at org.junit.platform.commons.util.ReflectionUtils.invokeMethod(ReflectionUtils.java:725)
                    at org.junit.jupiter.engine.execution.MethodInvocation.proceed(MethodInvocation.java:60)
                """.trimIndent()
            )
        }
    }
}