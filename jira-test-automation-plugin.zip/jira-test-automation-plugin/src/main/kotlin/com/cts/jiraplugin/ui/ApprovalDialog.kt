package com.cts.jiraplugin.ui

import com.intellij.openapi.ui.DialogWrapper
import java.awt.BorderLayout
import java.awt.Color
import java.awt.Dimension
import java.awt.FlowLayout
import java.awt.Font
import javax.swing.JComponent
import javax.swing.JLabel
import javax.swing.JPanel
import javax.swing.JScrollPane
import javax.swing.JTextArea

class ApprovalDialog(
    private val testName: String,
    private val errorMessage: String,
    private val stackTrace: String,
    private val severity: String? = null,
    private val probableCause: String? = null,
    private val isDuplicate: Boolean = false
) : DialogWrapper(true) {
    var isApproved = false

    init {
        init()
        title = "Create Jira Ticket for Test Failure"
        setOKButtonText("Create Ticket")
        setCancelButtonText("Cancel")
    }

    override fun createCenterPanel(): JComponent {
        val panel = JPanel(BorderLayout(5, 5))

        // Add severity and duplicate info
        val infoPanel = JPanel(FlowLayout(FlowLayout.LEFT))

        severity?.let {
            val color = when (it.toLowerCase()) {
                "critical" -> Color.RED
                "major" -> Color.ORANGE
                else -> Color.YELLOW
            }
            val severityLabel = JLabel("Severity: $it").apply {
                foreground = color
                font = font.deriveFont(Font.BOLD)
            }
            infoPanel.add(severityLabel)
        }

        if (isDuplicate) {
            val duplicateLabel = JLabel("⚠️ Possible Duplicate").apply {
                foreground = Color.BLUE
                font = font.deriveFont(Font.BOLD)
            }
            infoPanel.add(duplicateLabel)
        }

        panel.add(infoPanel, BorderLayout.NORTH)

        // Add probable cause if available
        probableCause?.let { cause ->
            val causeArea = JTextArea("Probable cause: $cause").apply {
                isEditable = false
                lineWrap = true
                wrapStyleWord = true
                background = panel.background
            }
            panel.add(causeArea, BorderLayout.CENTER)
        }

        // Error message and stack trace
        val errorDetails = JTextArea("Test: $testName\n\nError: $errorMessage\n\nStack Trace:\n$stackTrace")
        errorDetails.isEditable = false
        errorDetails.lineWrap = true
        errorDetails.wrapStyleWord = true

        val scrollPane = JScrollPane(errorDetails)
        scrollPane.preferredSize = Dimension(500, 300)

        if (probableCause != null) {
            // If we have a probable cause, add error details to the south
            panel.add(scrollPane, BorderLayout.SOUTH)
        } else {
            // Otherwise add to center
            panel.add(scrollPane, BorderLayout.CENTER)
        }

        return panel
    }

    override fun doOKAction() {
        isApproved = true
        super.doOKAction()
    }
}