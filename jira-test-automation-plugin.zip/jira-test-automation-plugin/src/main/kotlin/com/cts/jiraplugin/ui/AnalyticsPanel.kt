package com.cts.jiraplugin.ui

import com.intellij.openapi.application.ApplicationManager
import com.intellij.openapi.ui.SimpleToolWindowPanel
import com.intellij.ui.components.JBLabel
import com.intellij.ui.components.JBPanel
import com.intellij.ui.components.JBScrollPane
import com.intellij.ui.components.JBTextArea
import com.intellij.util.ui.JBUI
import com.cts.jiraplugin.persistence.DatabaseManager
import java.awt.BorderLayout
import java.awt.GridLayout
import javax.swing.JLabel
import javax.swing.JPanel
import javax.swing.SwingConstants
import javax.swing.SwingUtilities

class AnalyticsPanel : SimpleToolWindowPanel(false, true) {
    private val mainPanel = JBPanel<JBPanel<*>>(BorderLayout())

    init {
        setContent(mainPanel)
        showLoading()
        loadAnalyticsData()
    }

    private fun showLoading() {
        mainPanel.removeAll()
        mainPanel.add(JBLabel("Loading analytics data...", SwingConstants.CENTER), BorderLayout.CENTER)
        mainPanel.revalidate()
        mainPanel.repaint()
    }

    private fun loadAnalyticsData() {
        ApplicationManager.getApplication().executeOnPooledThread {
            try {
                // Perform blocking DB operations on a background thread
                val stats = DatabaseManager.getAnalyticsStats()
                val passFailData = DatabaseManager.getPassFailData()
                val ticketData = DatabaseManager.getTicketTypeData()

                // Update UI on the Event Dispatch Thread
                SwingUtilities.invokeLater {
                    buildUi(stats, passFailData, ticketData)
                }
            } catch (e: Exception) {
                SwingUtilities.invokeLater {
                    showError("Failed to load analytics: ${e.message}")
                }
            }
        }
    }

    private fun buildUi(stats: com.cts.jiraplugin.persistence.AnalyticsStats,
                        passFailData: com.cts.jiraplugin.persistence.PassFailData,
                        ticketData: com.cts.jiraplugin.persistence.TicketTypeData) {
        mainPanel.removeAll()
        mainPanel.border = JBUI.Borders.empty(10)

        val tabbedPane = JPanel(BorderLayout())

        // Stats panel
        val statsPanel = createStatsPanel(stats)
        tabbedPane.add(statsPanel, BorderLayout.NORTH)

        // Data panels
        val dataPanel = JPanel(GridLayout(1, 2, 10, 10))

        // Pass/Fail data as text
        val passFailText = JBTextArea()
        passFailText.text = "Test Results Over Time:\n" +
                passFailData.dates.zip(passFailData.passed.zip(passFailData.failed)).joinToString("\n") {
                        (date, counts) -> "$date: ${counts.first} passed, ${counts.second} failed"
                }
        passFailText.isEditable = false
        dataPanel.add(JBScrollPane(passFailText))

        // Ticket data as text
        val ticketText = JBTextArea()
        ticketText.text = "Ticket Types:\n" +
                ticketData.labels.zip(ticketData.values).joinToString("\n") {
                        (label, value) -> "$label: $value"
                }
        ticketText.isEditable = false
        dataPanel.add(JBScrollPane(ticketText))

        tabbedPane.add(dataPanel, BorderLayout.CENTER)
        mainPanel.add(tabbedPane, BorderLayout.CENTER)

        mainPanel.revalidate()
        mainPanel.repaint()
    }

    private fun createStatsPanel(stats: com.cts.jiraplugin.persistence.AnalyticsStats): JPanel {
        val panel = JPanel(GridLayout(2, 4, 10, 10))

        panel.add(createStatCard("Total Tests", stats.totalTests.toString()))
        panel.add(createStatCard("Passed", stats.passedTests.toString()))
        panel.add(createStatCard("Failed", stats.failedTests.toString()))
        panel.add(createStatCard("Success Rate", "${String.format("%.1f", stats.successRate)}%"))

        panel.add(createStatCard("Tickets Created", stats.ticketsCreated.toString()))
        panel.add(createStatCard("Critical Issues", stats.criticalIssues.toString()))
        panel.add(createStatCard("Avg Resolution Time", stats.avgResolutionTime))
        panel.add(createStatCard("Open Tickets", stats.openTickets.toString()))

        return panel
    }

    private fun createStatCard(title: String, value: String): JPanel {
        val panel = JPanel(BorderLayout())
        panel.border = JBUI.Borders.empty(5)

        val titleLabel = JBLabel(title, JLabel.CENTER)
        val valueLabel = JBLabel(value, JLabel.CENTER)
        valueLabel.font = valueLabel.font.deriveFont(18f)

        panel.add(titleLabel, BorderLayout.NORTH)
        panel.add(valueLabel, BorderLayout.CENTER)

        return panel
    }

    private fun showError(message: String) {
        mainPanel.removeAll()
        mainPanel.add(JBLabel("Error: $message", SwingConstants.CENTER), BorderLayout.CENTER)
        mainPanel.revalidate()
        mainPanel.repaint()
    }
}