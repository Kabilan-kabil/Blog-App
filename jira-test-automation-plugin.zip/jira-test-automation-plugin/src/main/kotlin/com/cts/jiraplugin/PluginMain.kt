package com.cts.jiraplugin

import com.intellij.openapi.components.BaseComponent
import com.intellij.openapi.project.Project
import com.intellij.openapi.startup.StartupActivity
import com.cts.jiraplugin.core.TestFailureDetector
import com.cts.jiraplugin.persistence.DatabaseManager

class PluginMain : BaseComponent {
    companion object {
        const val PLUGIN_ID = "com.cts.jira-test-automation-plugin"
    }

    override fun initComponent() {
        // Initialize plugin components
        DatabaseManager.initializeDatabase()
        DatabaseManager.ensureTestRunsTable()
        DatabaseManager.ensureJiraTicketsEnhanced()
        TestFailureDetector.startMonitoring()
    }

    override fun disposeComponent() {
        // Clean up resources
    }
}

class PluginStartupActivity : StartupActivity {
    override fun runActivity(project: Project) {
        // Initialize plugin when project is loaded
        DatabaseManager.initializeDatabase()
        DatabaseManager.ensureTestRunsTable()
        DatabaseManager.ensureJiraTicketsEnhanced()
        TestFailureDetector.startMonitoring()
    }
}