package com.cts.jiraplugin.auth

import com.sun.net.httpserver.HttpServer
import com.intellij.openapi.application.ApplicationManager
import com.intellij.openapi.diagnostic.Logger
import com.intellij.openapi.progress.ProgressIndicator
import com.intellij.openapi.progress.ProgressManager
import com.intellij.openapi.progress.Task
import com.intellij.openapi.ui.Messages
import com.intellij.util.io.HttpRequests
import org.json.JSONArray
import org.json.JSONObject
import java.awt.Desktop
import java.net.InetSocketAddress
import java.net.URI
import java.net.URLEncoder
import java.util.*

interface AuthListener {
    fun onAuthSuccess(resources: List<JiraResource>)
    fun onAuthFailure(message: String)
}

object OAuthManager {
    private val logger = Logger.getInstance(OAuthManager::class.java)

    // These values should be obtained from your plugin registration with Atlassian
    private const val CLIENT_ID = "0giKrzpgRLaRcpxDgF9bODYxSZxsIE59"
    private const val CLIENT_SECRET = "ATOAo79ucQIOgcQ8wu4zvBczdTE7ZYXRTmels2AeiZqjLHAedHx50NIb9nmGoFYq4-ax72FD891D"
    private const val REDIRECT_URI = "http://localhost:8089/callback" // Example port
    private const val AUTH_URL = "https://auth.atlassian.com/authorize"
    private const val TOKEN_URL = "https://auth.atlassian.com/oauth/token"
    private const val RESOURCE_URL = "https://api.atlassian.com/oauth/token/accessible-resources"

    private var accessToken: String? = null
    private var refreshToken: String? = null
    private var tokenExpiry: Long = 0
    private var state: String? = null
    private var redirectServer: HttpServer? = null
    private val listeners = mutableListOf<AuthListener>()

    fun addListener(listener: AuthListener) {
        listeners.add(listener)
    }

    fun initiateOAuthFlow() {
        try {
            // Start a local server to listen for the redirect
            startRedirectListener()

            // Generate state parameter for CSRF protection
            state = UUID.randomUUID().toString()

            // Build authorization URL
            val authUrl = buildAuthUrl()

            // Open browser for authentication
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(URI(authUrl))
            } else {
                Messages.showErrorDialog("Could not open browser for authentication", "OAuth Error")
                stopRedirectListener()
            }
        } catch (e: Exception) {
            logger.error("OAuth initiation failed: ${e.message}")
            Messages.showErrorDialog("OAuth authentication failed: ${e.message}", "Authentication Error")
            stopRedirectListener()
        }
    }

    private fun buildAuthUrl(): String {
        val params = mapOf(
            "audience" to "api.atlassian.com",
            "client_id" to CLIENT_ID,
            // Use modern, granular scopes for better security and user trust.
            "scope" to "write:issue:jira read:issue:jira read:me offline_access",
            "redirect_uri" to REDIRECT_URI,
            "state" to state!!,
            "response_type" to "code",
            "prompt" to "consent"
        )
        return "$AUTH_URL?" + params.map { (k, v) ->
            "${URLEncoder.encode(k, "UTF-8")}=${URLEncoder.encode(v, "UTF-8")}"
        }.joinToString("&")
    }

    private fun startRedirectListener() {
        val port = URI(REDIRECT_URI).port
        redirectServer = HttpServer.create(InetSocketAddress(port), 0)
        redirectServer?.createContext("/callback") { exchange ->
            val queryParams = exchange.requestURI.query.split('&').associate {
                val parts = it.split('=')
                parts[0] to parts.getOrElse(1) { "" }
            }

            val receivedCode = queryParams["code"]
            val receivedState = queryParams["state"]

            val responseText: String
            if (receivedState != null && receivedState == state && receivedCode != null) {
                ApplicationManager.getApplication().executeOnPooledThread {
                    exchangeCodeForTokens(receivedCode)
                }
                responseText = "Authentication successful! You can now close this tab."
            } else {
                responseText = "Authentication failed. Please try again."
                logger.warn("OAuth callback state mismatch or code missing.")
                ApplicationManager.getApplication().invokeLater {
                    listeners.forEach { it.onAuthFailure("Authentication failed: State mismatch or code missing.") }
                }
            }

            exchange.sendResponseHeaders(200, responseText.toByteArray().size.toLong())
            exchange.responseBody.use { it.write(responseText.toByteArray()) }
            stopRedirectListener()
        }
        redirectServer?.start()
    }

    private fun exchangeCodeForTokens(authorizationCode: String) {
        ProgressManager.getInstance().run(object : Task.Modal(null, "Authenticating with Jira", false) {
            override fun run(indicator: ProgressIndicator) {
                indicator.isIndeterminate = true
                indicator.text = "Fetching access tokens..."
                try {
                    val requestBody = mapOf(
                        "grant_type" to "authorization_code",
                        "client_id" to CLIENT_ID,
                        "client_secret" to CLIENT_SECRET,
                        "code" to authorizationCode,
                        "redirect_uri" to REDIRECT_URI
                    )

                    val response = HttpRequests.post(TOKEN_URL, "application/json")
                        .connect {
                            it.write(JSONObject(requestBody).toString())
                            it.readString()
                        }

                    val jsonResponse = JSONObject(response)
                    accessToken = jsonResponse.getString("access_token")
                    refreshToken = jsonResponse.getString("refresh_token")
                    tokenExpiry = System.currentTimeMillis() + (jsonResponse.getLong("expires_in") * 1000)

                    // Store tokens securely
                    storeTokensSecurely()

                    // Get accessible resources (Jira instances)
                    // This might require user interaction, so it's a good next step.
                    val resources = getAccessibleResources()
                    ApplicationManager.getApplication().invokeLater {
                        listeners.forEach { it.onAuthSuccess(resources) }
                    }

                } catch (e: Exception) {
                    logger.error("Token exchange failed: ${e.message}")
                    ApplicationManager.getApplication().invokeLater {
                        listeners.forEach { it.onAuthFailure("Failed to obtain access token: ${e.message}") }
                    }
                }
            }
        })
    }

    private fun stopRedirectListener() {
        redirectServer?.stop(0)
        redirectServer = null
    }

    private fun refreshAccessToken() {
        if (refreshToken == null) {
            // Cannot refresh without a refresh token, need to re-authenticate
            logger.warn("Refresh token is null. Full re-authentication is required.")
            // In a real app, you might want to notify the user here before popping the browser.
            ApplicationManager.getApplication().invokeLater { initiateOAuthFlow() }
            return
        }

        logger.info("Access token expired. Refreshing...")
        try {
            val requestBody = mapOf(
                "grant_type" to "refresh_token",
                "client_id" to CLIENT_ID,
                "client_secret" to CLIENT_SECRET,
                "refresh_token" to refreshToken
            )

            val response = HttpRequests.post(TOKEN_URL, "application/json")
                .connect {
                    it.write(JSONObject(requestBody).toString())
                    it.readString()
                }

            val jsonResponse = JSONObject(response)
            accessToken = jsonResponse.getString("access_token")
            refreshToken = jsonResponse.getString("refresh_token")
            tokenExpiry = System.currentTimeMillis() + (jsonResponse.getLong("expires_in") * 1000)

            // Store tokens securely
            storeTokensSecurely()

        } catch (e: Exception) {
            logger.error("Token refresh failed: ${e.message}")
            // If refresh fails, initiate new OAuth flow
            ApplicationManager.getApplication().invokeLater {
                listeners.forEach { it.onAuthFailure("Session expired. Please log in again.") }
                initiateOAuthFlow()
            }
        }
    }

    fun getAccessToken(): String? {
        if (accessToken == null) {
            loadTokens()
        }

        // Check if token is expired or about to expire (60-second buffer)
        if (accessToken != null && System.currentTimeMillis() > tokenExpiry - 60000) {
            // Token is expired, refresh it synchronously on a background thread.
            // This blocks the current thread but shows a progress dialog to the user,
            // ensuring the caller gets a valid token.
            ProgressManager.getInstance().run(object : Task.Modal(null, "Refreshing Jira Authentication", false) {
                override fun run(indicator: ProgressIndicator) {
                    indicator.isIndeterminate = true
                    refreshAccessToken()
                }
            })
        }

        return accessToken
    }

    private fun storeTokensSecurely() {
        if (accessToken == null || refreshToken == null) {
            return // Don't store null tokens
        }
        // Use IntelliJ's PasswordSafe to store tokens securely
        val credentialAttributes = com.intellij.credentialStore.CredentialAttributes(
            "JiraPluginOAuthTokens",
            "Jira Plugin OAuth Tokens"
        )

        val tokens = mapOf(
            "access_token" to accessToken,
            "refresh_token" to refreshToken,
            "expiry" to tokenExpiry.toString()
        )

        com.intellij.ide.passwordSafe.PasswordSafe.instance.setPassword(
            credentialAttributes,
            JSONObject(tokens).toString()
        )
    }

    fun loadTokens() {
        try {
            val credentialAttributes = com.intellij.credentialStore.CredentialAttributes(
                "JiraPluginOAuthTokens",
                "Jira Plugin OAuth Tokens"
            )

            val tokensJson = com.intellij.ide.passwordSafe.PasswordSafe.instance.getPassword(credentialAttributes)
            if (tokensJson != null) {
                val tokens = JSONObject(tokensJson)
                accessToken = tokens.optString("access_token", null)
                refreshToken = tokens.optString("refresh_token", null)
                tokenExpiry = tokens.optLong("expiry", 0)

                // Check if token needs refreshing
                // The getAccessToken() method will handle the refresh check,
                // so we don't need to do it eagerly here on load.
                logger.info("OAuth tokens loaded from secure storage.")
            }
        } catch (e: Exception) {
            logger.error("Failed to load tokens: ${e.message}")
        }
    }

    fun getAccessibleResources(): List<JiraResource> {
        val resources = mutableListOf<JiraResource>()
        val token = getAccessToken()

        if (token == null) {
            logger.warn("Cannot get accessible resources without an access token.")
            return resources
        }

        try {
            val url = URL(RESOURCE_URL)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.setRequestProperty("Authorization", "Bearer $token")
            connection.setRequestProperty("Content-Type", "application/json")

            when (connection.responseCode) {
                HttpURLConnection.HTTP_OK -> {
                    val response = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val jsonArray = JSONArray(response)
                    for (i in 0 until jsonArray.length()) {
                        val resource = jsonArray.getJSONObject(i)
                        resources.add(
                            JiraResource(
                                resource.getString("id"),
                                resource.getString("name"),
                                resource.getString("url"),
                                resource.optString("avatarUrl", "")
                            )
                        )
                    }
                }
                else -> {
                    logger.warn("Failed to get accessible resources: ${connection.responseCode}")
                }
            }
        } catch (e: Exception) {
            logger.error("Failed to get accessible resources: ${e.message}")
        }

        return resources
    }

    
    fun logout() {
        accessToken = null
        refreshToken = null
        tokenExpiry = 0

        // Remove tokens from secure storage
        val credentialAttributes = com.intellij.credentialStore.CredentialAttributes(
            "JiraPluginOAuthTokens",
            "Jira Plugin OAuth Tokens"
        )

        com.intellij.ide.passwordSafe.PasswordSafe.instance.setPassword(credentialAttributes, null)
        logger.info("User logged out and tokens cleared.")
    }
}

data class JiraResource(
    val id: String,
    val name: String,
    val url: String,
    val avatarUrl: String
)