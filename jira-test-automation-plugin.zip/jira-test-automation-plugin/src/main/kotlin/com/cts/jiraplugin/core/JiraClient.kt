package com.cts.jiraplugin.core

import com.cts.jiraplugin.auth.OAuthManager
import com.intellij.openapi.ui.Messages
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class JiraClient(private val baseUrl: String) {

    /**
     * Creates a new issue in Jira.
     * Note: This performs a blocking network request and should be called from a background thread.
     */
    fun createIssue(projectKey: String, summary: String, description: String, issueType: String): String? {
        val issueBody = JSONObject().apply {
            put("fields", JSONObject().apply {
                put("project", JSONObject().put("key", projectKey))
                put("summary", summary)
                put("description", description)
                put("issuetype", JSONObject().put("name", issueType))
            })
        }

        return executeRequest(
            endpoint = "/rest/api/2/issue",
            method = "POST",
            body = issueBody,
            successCode = HttpURLConnection.HTTP_CREATED
        ) { response ->
            JSONObject(response).getString("key")
        }
    }

    /**
     * Searches for issues using JQL.
     * Note: This performs a blocking network request and should be called from a background thread.
     */
    fun searchIssues(jql: String, fields: List<String> = listOf("key", "summary", "status", "assignee")): List<JiraIssue> {
        val requestBody = JSONObject().apply {
            put("jql", jql)
            put("fields", fields)
            put("maxResults", 50)
        }

        return executeRequest(
            endpoint = "/rest/api/2/search",
            method = "POST",
            body = requestBody,
            successCode = HttpURLConnection.HTTP_OK
        ) { response ->
            val issues = mutableListOf<JiraIssue>()
            val jsonResponse = JSONObject(response)
            val issuesArray = jsonResponse.getJSONArray("issues")

            for (i in 0 until issuesArray.length()) {
                val issue = issuesArray.getJSONObject(i)
                val key = issue.getString("key")
                val fieldsObj = issue.getJSONObject("fields")
                val summary = fieldsObj.getString("summary")
                val status = fieldsObj.getJSONObject("status").getString("name")
                val assignee = fieldsObj.optJSONObject("assignee")?.getString("displayName") ?: "Unassigned"

                issues.add(JiraIssue(key, summary, status, assignee))
            }
            issues
        } ?: emptyList()
    }

    /**
     * Assigns an issue to the currently logged-in user.
     * Note: This performs a blocking network request and should be called from a background thread.
     */
    fun assignToSelf(issueKey: String): Boolean {
        val userInfo = getCurrentUserInfo() ?: run {
            Messages.showErrorDialog("Could not get current user information to assign issue.", "Error")
            return false
        }

        val requestBody = JSONObject().put("accountId", userInfo.accountId)

        return executeRequest(
            endpoint = "/rest/api/2/issue/$issueKey/assignee",
            method = "PUT",
            body = requestBody,
            successCode = HttpURLConnection.HTTP_NO_CONTENT
        ) { true } ?: false
    }

    /**
     * Adds a comment to a Jira issue.
     * Note: This performs a blocking network request and should be called from a background thread.
     */
    fun addComment(issueKey: String, comment: String): Boolean {
        val requestBody = JSONObject().put("body", comment)

        return executeRequest(
            endpoint = "/rest/api/2/issue/$issueKey/comment",
            method = "POST",
            body = requestBody,
            successCode = HttpURLConnection.HTTP_CREATED
        ) { true } ?: false
    }

    /**
     * Gets information about the currently authenticated user.
     * Note: This performs a blocking network request and should be called from a background thread.
     */
    fun getCurrentUserInfo(): UserInfo? {
        return executeRequest(endpoint = "/rest/api/2/myself", successCode = HttpURLConnection.HTTP_OK) { response ->
            val jsonResponse = JSONObject(response)
            UserInfo(
                jsonResponse.getString("accountId"),
                jsonResponse.getString("displayName"),
                jsonResponse.getString("emailAddress")
            )
        }
    }

    fun getIssueUrl(issueKey: String): String {
        return "$baseUrl/browse/$issueKey"
    }

    /**
     * A generic, reusable function to execute authenticated requests to the Jira API.
     * It handles getting the token, setting up the connection, and basic error handling.
     */
    private fun <T> executeRequest(
        endpoint: String,
        method: String = "GET",
        body: JSONObject? = null,
        successCode: Int,
        parser: (String) -> T
    ): T? {
        val accessToken = OAuthManager.getAccessToken()
        if (accessToken == null) {
            Messages.showErrorDialog("Not authenticated with Jira. Please log in.", "Authentication Required")
            return null
        }

        try {
            val url = URL(baseUrl + endpoint)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = method
            connection.setRequestProperty("Authorization", "Bearer $accessToken")
            connection.setRequestProperty("Accept", "application/json")

            if (body != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json")
                connection.outputStream.use { os ->
                    val input = body.toString().toByteArray(Charsets.UTF_8)
                    os.write(input, 0, input.size)
                }
            }

            return if (connection.responseCode == successCode) {
                // For HTTP 204 No Content, there is no response body to parse.
                if (successCode == HttpURLConnection.HTTP_NO_CONTENT) {
                    @Suppress("UNCHECKED_CAST")
                    true as T // A bit of a hack for boolean success, but works for our case.
                } else {
                    val responseString = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    parser(responseString)
                }
            } else {
                val errorStream = connection.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                Messages.showErrorDialog(
                    "API request failed: ${connection.responseCode} ${connection.responseMessage}\n$errorStream",
                    "Jira API Error"
                )
                null
            }
        } catch (e: Exception) {
            Messages.showErrorDialog("Error during API request: ${e.message}", "Error")
            return null
        }
    }
}

data class JiraIssue(
    val key: String,
    val summary: String,
    val status: String,
    val assignee: String
)

data class UserInfo(
    val accountId: String,
    val displayName: String,
    val emailAddress: String
)