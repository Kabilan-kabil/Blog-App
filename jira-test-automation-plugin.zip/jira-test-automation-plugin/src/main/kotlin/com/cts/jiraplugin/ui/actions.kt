package com.cts.jiraplugin.ui.actions

import com.cts.jiraplugin.auth.OAuthManager
import com.cts.jiraplugin.ui.LoginDialog
import com.intellij.openapi.actionSystem.AnAction
import com.intellij.openapi.actionSystem.AnActionEvent
import com.intellij.openapi.project.Project
import com.intellij.openapi.wm.ToolWindowManager

class LoginAction : AnAction("Login", "Login to Jira", null) {
    override fun actionPerformed(e: AnActionEvent) {
        val dialog = LoginDialog()
        dialog.show()
    }
}

class LogoutAction : AnAction("Logout", "Logout from Jira", null) {
    override fun actionPerformed(e: AnActionEvent) {
        OAuthManager.logout()
        val project = e.project
        val toolWindow = ToolWindowManager.getInstance(project).getToolWindow("Jira Test Failures")
        val content = toolWindow?.contentManager?.selectedContent
        val panel = content?.component as? com.cts.jiraplugin.ui.EnhancedPluginPanel
        panel?.showLoginPrompt()
    }
}

class RefreshAction : AnAction("Refresh", "Refresh data", null) {
    override fun actionPerformed(e: AnActionEvent) {
        val project = e.project
        val toolWindow = ToolWindowManager.getInstance(project).getToolWindow("Jira Test Failures")
        val content = toolWindow?.contentManager?.selectedContent
        val panel = content?.component as? com.cts.jiraplugin.ui.EnhancedPluginPanel
        panel?.refresh()
    }
}