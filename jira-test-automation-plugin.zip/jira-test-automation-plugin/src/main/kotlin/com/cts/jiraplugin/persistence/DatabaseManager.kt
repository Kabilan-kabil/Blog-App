package com.cts.jiraplugin.persistence

import com.intellij.openapi.application.PathManager
import java.io.File
import java.sql.*
import java.util.*
import kotlin.math.sqrt

object DatabaseManager {
    private const val DATABASE_NAME = "test_failures.db"
    private val databasePath: String
        get() = PathManager.getConfigPath() + File.separator + DATABASE_NAME

    fun initializeDatabase() {
        val sql = """
            CREATE TABLE IF NOT EXISTS jira_tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                test_name TEXT NOT NULL,
                jira_key TEXT NOT NULL,
                jira_url TEXT NOT NULL,
                status TEXT DEFAULT 'Open',
                severity TEXT DEFAULT 'Major',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                resolved_at DATETIME
            );
            
            CREATE TABLE IF NOT EXISTS test_failures (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                test_name TEXT NOT NULL,
                error_message TEXT NOT NULL,
                embedding TEXT,
                severity TEXT,
                probable_cause TEXT,
                status TEXT DEFAULT 'Pending',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
            
            CREATE TABLE IF NOT EXISTS test_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                test_name TEXT NOT NULL,
                status TEXT NOT NULL,
                error_message TEXT,
                duration_ms INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
            
            CREATE INDEX IF NOT EXISTS idx_test_failures_created ON test_failures(created_at);
            CREATE INDEX IF NOT EXISTS idx_jira_tickets_created ON jira_tickets(created_at);
            CREATE INDEX IF NOT EXISTS idx_test_runs_created ON test_runs(created_at);
            CREATE INDEX IF NOT EXISTS idx_jira_tickets_status ON jira_tickets(status);
            CREATE INDEX IF NOT EXISTS idx_jira_tickets_severity ON jira_tickets(severity);
        """.trimIndent()

        getConnection().use { conn ->
            conn.createStatement().execute(sql)
        }
    }

    fun storeTicket(testName: String, jiraKey: String, jiraUrl: String, severity: String = "Major") {
        val sql = "INSERT INTO jira_tickets(test_name, jira_key, jira_url, severity) VALUES(?, ?, ?, ?)"

        getConnection().use { conn ->
            conn.prepareStatement(sql).use { stmt ->
                stmt.setString(1, testName)
                stmt.setString(2, jiraKey)
                stmt.setString(3, jiraUrl)
                stmt.setString(4, severity)
                stmt.executeUpdate()
            }
        }
    }

    fun updateTicketStatus(jiraKey: String, status: String) {
        val sql = "UPDATE jira_tickets SET status = ? WHERE jira_key = ?"

        getConnection().use { conn ->
            conn.prepareStatement(sql).use { stmt ->
                stmt.setString(1, status)
                stmt.setString(2, jiraKey)
                stmt.executeUpdate()
            }
        }

        // If status is resolved, set resolved_at timestamp
        if (status.equals("Resolved", ignoreCase = true)) {
            val resolveSql = "UPDATE jira_tickets SET resolved_at = CURRENT_TIMESTAMP WHERE jira_key = ?"
            getConnection().use { conn ->
                conn.prepareStatement(resolveSql).use { stmt ->
                    stmt.setString(1, jiraKey)
                    stmt.executeUpdate()
                }
            }
        }
    }

    fun updateTicketSeverity(jiraKey: String, severity: String) {
        val sql = "UPDATE jira_tickets SET severity = ? WHERE jira_key = ?"

        getConnection().use { conn ->
            conn.prepareStatement(sql).use { stmt ->
                stmt.setString(1, severity)
                stmt.setString(2, jiraKey)
                stmt.executeUpdate()
            }
        }
    }

    fun storeFailureWithEmbedding(testName: String, errorMessage: String, embedding: List<Double>, severity: String? = null, probableCause: String? = null) {
        val sql = "INSERT INTO test_failures(test_name, error_message, embedding, severity, probable_cause) VALUES(?, ?, ?, ?, ?)"

        getConnection().use { conn ->
            conn.prepareStatement(sql).use { stmt ->
                stmt.setString(1, testName)
                stmt.setString(2, errorMessage)
                stmt.setString(3, embedding.joinToString(","))
                stmt.setString(4, severity)
                stmt.setString(5, probableCause)
                stmt.executeUpdate()
            }
        }
    }

    fun updateFailureStatus(testName: String, errorMessage: String, status: String) {
        val sql = "UPDATE test_failures SET status = ? WHERE test_name = ? AND error_message = ? AND created_at = (SELECT MAX(created_at) FROM test_failures WHERE test_name = ? AND error_message = ?)"

        getConnection().use { conn ->
            conn.prepareStatement(sql).use { stmt ->
                stmt.setString(1, status)
                stmt.setString(2, testName)
                stmt.setString(3, errorMessage)
                stmt.setString(4, testName)
                stmt.setString(5, errorMessage)
                stmt.executeUpdate()
            }
        }
    }

    fun storeTestRun(testName: String, status: String, errorMessage: String? = null, durationMs: Long? = null) {
        val sql = "INSERT INTO test_runs(test_name, status, error_message, duration_ms) VALUES(?, ?, ?, ?)"

        getConnection().use { conn ->
            conn.prepareStatement(sql).use { stmt ->
                stmt.setString(1, testName)
                stmt.setString(2, status)
                stmt.setString(3, errorMessage)
                stmt.setLong(4, durationMs ?: 0)
                stmt.executeUpdate()
            }
        }
    }

    fun getTickets(): List<JiraTicket> {
        val sql = "SELECT test_name, jira_key, jira_url, status, severity, created_at, resolved_at FROM jira_tickets ORDER BY created_at DESC"
        val tickets = mutableListOf<JiraTicket>()

        getConnection().use { conn ->
            conn.createStatement().use { stmt ->
                stmt.executeQuery(sql).use { rs ->
                    while (rs.next()) {
                        tickets.add(
                            JiraTicket(
                                rs.getString("test_name"),
                                rs.getString("jira_key"),
                                rs.getString("jira_url"),
                                rs.getString("status"),
                                rs.getString("severity"),
                                rs.getTimestamp("created_at"),
                                rs.getTimestamp("resolved_at")
                            )
                        )
                    }
                }
            }
        }

        return tickets
    }

    fun getFailures(): List<TestFailure> {
        val sql = "SELECT test_name, error_message, severity, probable_cause, status, created_at FROM test_failures ORDER BY created_at DESC"
        val failures = mutableListOf<TestFailure>()

        getConnection().use { conn ->
            conn.createStatement().use { stmt ->
                stmt.executeQuery(sql).use { rs ->
                    while (rs.next()) {
                        failures.add(
                            TestFailure(
                                rs.getString("test_name"),
                                rs.getString("error_message"),
                                rs.getString("severity"),
                                rs.getString("probable_cause"),
                                rs.getString("status"),
                                rs.getTimestamp("created_at")
                            )
                        )
                    }
                }
            }
        }

        return failures
    }

    fun getRecentFailures(hours: Int): List<Map<String, Any>> {
        val sql = "SELECT test_name, error_message, embedding, severity, probable_cause, status, created_at FROM test_failures WHERE created_at > datetime('now', ?) ORDER BY created_at DESC"
        val failures = mutableListOf<Map<String, Any>>()

        getConnection().use { conn ->
            conn.prepareStatement(sql).use { stmt ->
                stmt.setString(1, "-$hours hours")
                stmt.executeQuery().use { rs ->
                    while (rs.next()) {
                        failures.add(mapOf(
                            "test_name" to rs.getString("test_name"),
                            "error_message" to rs.getString("error_message"),
                            "embedding" to (rs.getString("embedding")?.split(",")?.map { it.toDouble() } ?: emptyList()),
                            "severity" to rs.getString("severity"),
                            "probable_cause" to rs.getString("probable_cause"),
                            "status" to rs.getString("status"),
                            "created_at" to rs.getTimestamp("created_at")
                        ))
                    }
                }
            }
        }

        return failures
    }

    fun getFailureStats(days: Int = 7): FailureStats {
        val sql = """
            SELECT 
                COUNT(*) as total_failures,
                COUNT(DISTINCT test_name) as unique_tests,
                AVG(CASE WHEN severity = 'Critical' THEN 1 ELSE 0 END) * 100 as critical_percent,
                AVG(CASE WHEN severity = 'Major' THEN 1 ELSE 0 END) * 100 as major_percent,
                AVG(CASE WHEN severity = 'Minor' THEN 1 ELSE 0 END) * 100 as minor_percent,
                AVG(CASE WHEN status = 'Resolved' THEN 1 ELSE 0 END) * 100 as resolved_percent
            FROM test_failures 
            WHERE created_at > datetime('now', ?)
        """.trimIndent()

        getConnection().use { conn ->
            conn.prepareStatement(sql).use { stmt ->
                stmt.setString(1, "-$days days")
                stmt.executeQuery().use { rs ->
                    if (rs.next()) {
                        return FailureStats(
                            totalFailures = rs.getInt("total_failures"),
                            uniqueTests = rs.getInt("unique_tests"),
                            criticalPercent = rs.getDouble("critical_percent"),
                            majorPercent = rs.getDouble("major_percent"),
                            minorPercent = rs.getDouble("minor_percent"),
                            resolvedPercent = rs.getDouble("resolved_percent")
                        )
                    }
                }
            }
        }

        return FailureStats()
    }

    fun getAnalyticsStats(): AnalyticsStats {
        // Total tests
        val totalTests = getConnection().use { conn ->
            conn.createStatement().use { stmt ->
                stmt.executeQuery("SELECT COUNT(*) FROM test_runs").use { rs ->
                    if (rs.next()) rs.getInt(1) else 0
                }
            }
        }

        // Passed tests
        val passedTests = getConnection().use { conn ->
            conn.createStatement().use { stmt ->
                stmt.executeQuery("SELECT COUNT(*) FROM test_runs WHERE status = 'PASSED'").use { rs ->
                    if (rs.next()) rs.getInt(1) else 0
                }
            }
        }

        // Failed tests
        val failedTests = totalTests - passedTests

        // Success rate
        val successRate = if (totalTests > 0) (passedTests.toDouble() / totalTests * 100) else 0.0

        // Tickets created
        val ticketsCreated = getConnection().use { conn ->
            conn.createStatement().use { stmt ->
                stmt.executeQuery("SELECT COUNT(*) FROM jira_tickets").use { rs ->
                    if (rs.next()) rs.getInt(1) else 0
                }
            }
        }

        // Critical issues
        val criticalIssues = getConnection().use { conn ->
            conn.createStatement().use { stmt ->
                stmt.executeQuery("SELECT COUNT(*) FROM jira_tickets WHERE severity = 'Critical'").use { rs ->
                    if (rs.next()) rs.getInt(1) else 0
                }
            }
        }

        // Average resolution time
        val avgResolutionTime = getConnection().use { conn ->
            conn.createStatement().use { stmt ->
                stmt.executeQuery("""
                    SELECT AVG(JULIANDAY(resolved_at) - JULIANDAY(created_at)) 
                    FROM jira_tickets 
                    WHERE resolved_at IS NOT NULL
                """).use { rs ->
                    if (rs.next()) {
                        val days = rs.getDouble(1)
                        if (days < 1) "${(days * 24).toInt()} hours"
                        else "${days.toInt()} days"
                    } else {
                        "N/A"
                    }
                }
            }
        }

        // Open tickets
        val openTickets = getConnection().use { conn ->
            conn.createStatement().use { stmt ->
                stmt.executeQuery("SELECT COUNT(*) FROM jira_tickets WHERE status != 'Resolved'").use { rs ->
                    if (rs.next()) rs.getInt(1) else 0
                }
            }
        }

        return AnalyticsStats(
            totalTests = totalTests,
            passedTests = passedTests,
            failedTests = failedTests,
            successRate = successRate,
            ticketsCreated = ticketsCreated,
            criticalIssues = criticalIssues,
            avgResolutionTime = avgResolutionTime,
            openTickets = openTickets
        )
    }

    fun getPassFailData(): PassFailData {
        val dates = mutableListOf<String>()
        val passed = mutableListOf<Int>()
        val failed = mutableListOf<Int>()

        getConnection().use { conn ->
            conn.createStatement().use { stmt ->
                stmt.executeQuery("""
                    SELECT date(created_at) as day, 
                           SUM(CASE WHEN status = 'PASSED' THEN 1 ELSE 0 END) as passed,
                           SUM(CASE WHEN status = 'FAILED' THEN 1 ELSE 0 END) as failed
                    FROM test_runs
                    GROUP BY day
                    ORDER BY day DESC
                    LIMIT 10
                """).use { rs ->
                    while (rs.next()) {
                        dates.add(rs.getString("day"))
                        passed.add(rs.getInt("passed"))
                        failed.add(rs.getInt("failed"))
                    }
                }
            }
        }

        return PassFailData(dates.reversed(), passed.reversed(), failed.reversed())
    }

    fun getTicketTypeData(): TicketTypeData {
        val labels = mutableListOf<String>()
        val values = mutableListOf<Int>()

        getConnection().use { conn ->
            conn.createStatement().use { stmt ->
                stmt.executeQuery("""
                    SELECT severity, COUNT(*) as count
                    FROM jira_tickets
                    GROUP BY severity
                """).use { rs ->
                    while (rs.next()) {
                        labels.add(rs.getString("severity"))
                        values.add(rs.getInt("count"))
                    }
                }
            }
        }

        return TicketTypeData(labels, values)
    }

    fun getSimilarFailures(embedding: List<Double>, threshold: Double = 0.8, limit: Int = 5): List<Map<String, Any>> {
        val recentFailures = getRecentFailures(24) // Last 24 hours
        val similarFailures = mutableListOf<Map<String, Any>>()

        for (failure in recentFailures) {
            val existingEmbedding = failure["embedding"] as? List<Double> ?: continue
            val similarity = calculateCosineSimilarity(embedding, existingEmbedding)

            if (similarity >= threshold) {
                similarFailures.add(failure + ("similarity" to similarity))
            }

            if (similarFailures.size >= limit) {
                break
            }
        }

        return similarFailures.sortedByDescending { it["similarity"] as Double }
    }

    private fun calculateCosineSimilarity(vec1: List<Double>, vec2: List<Double>): Double {
        if (vec1.size != vec2.size || vec1.isEmpty()) return 0.0

        var dotProduct = 0.0
        var norm1 = 0.0
        var norm2 = 0.0

        for (i in vec1.indices) {
            dotProduct += vec1[i] * vec2[i]
            norm1 += vec1[i] * vec1[i]
            norm2 += vec2[i] * vec2[i]
        }

        return if (norm1 > 0 && norm2 > 0) {
            dotProduct / (sqrt(norm1) * sqrt(norm2))
        } else {
            0.0
        }
    }

    fun exportTicketsToCsv(): String {
        val tickets = getTickets()
        val csv = StringBuilder("Test Name,Jira Key,Jira URL,Status,Severity,Created At,Resolved At\n")

        tickets.forEach { ticket ->
            csv.append("\"${escapeCsv(ticket.testName)}\",")
            csv.append("\"${escapeCsv(ticket.jiraKey)}\",")
            csv.append("\"${escapeCsv(ticket.jiraUrl)}\",")
            csv.append("\"${escapeCsv(ticket.status)}\",")
            csv.append("\"${escapeCsv(ticket.severity)}\",")
            csv.append("\"${ticket.createdAt}\",")
            csv.append("\"${ticket.resolvedAt ?: ""}\"\n")
        }

        return csv.toString()
    }

    fun exportFailuresToCsv(): String {
        val failures = getFailures()
        val csv = StringBuilder("Test Name,Error Message,Severity,Probable Cause,Status,Created At\n")

        failures.forEach { failure ->
            csv.append("\"${escapeCsv(failure.testName)}\",")
            csv.append("\"${escapeCsv(failure.errorMessage)}\",")
            csv.append("\"${escapeCsv(failure.severity)}\",")
            csv.append("\"${escapeCsv(failure.probableCause)}\",")
            csv.append("\"${escapeCsv(failure.status)}\",")
            csv.append("\"${failure.createdAt}\"\n")
        }

        return csv.toString()
    }

    fun exportTestRunsToCsv(): String {
        val sql = "SELECT test_name, status, error_message, duration_ms, created_at FROM test_runs ORDER BY created_at DESC"
        val csv = StringBuilder("Test Name,Status,Error Message,Duration (ms),Created At\n")

        getConnection().use { conn ->
            conn.createStatement().use { stmt ->
                stmt.executeQuery(sql).use { rs ->
                    while (rs.next()) {
                        csv.append("\"${escapeCsv(rs.getString("test_name"))}\",")
                        csv.append("\"${escapeCsv(rs.getString("status"))}\",")
                        csv.append("\"${escapeCsv(rs.getString("error_message") ?: "")}\",")
                        csv.append("\"${rs.getLong("duration_ms")}\",")
                        csv.append("\"${rs.getTimestamp("created_at")}\"\n")
                    }
                }
            }
        }

        return csv.toString()
    }

    fun clearOldData(daysToKeep: Int = 30) {
        val sqls = listOf(
            "DELETE FROM jira_tickets WHERE created_at < datetime('now', ?)",
            "DELETE FROM test_failures WHERE created_at < datetime('now', ?)",
            "DELETE FROM test_runs WHERE created_at < datetime('now', ?)"
        )

        getConnection().use { conn ->
            for (sql in sqls) {
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setString(1, "-$daysToKeep days")
                    stmt.executeUpdate()
                }
            }
        }
    }

    // Add these methods to your DatabaseManager object
    fun ensureTestRunsTable() {
        val sql = """
        CREATE TABLE IF NOT EXISTS test_runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            test_name TEXT NOT NULL,
            status TEXT NOT NULL,
            error_message TEXT,
            duration_ms INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """.trimIndent()

        getConnection().use { conn ->
            conn.createStatement().execute(sql)
        }
    }

    fun ensureJiraTicketsEnhanced() {
        // Check if status column exists
        val checkStatus = "PRAGMA table_info(jira_tickets)"
        var hasStatus = false

        getConnection().use { conn ->
            conn.createStatement().executeQuery(checkStatus).use { rs ->
                while (rs.next()) {
                    if (rs.getString("name") == "status") {
                        hasStatus = true
                        break
                    }
                }
            }
        }

        if (!hasStatus) {
            getConnection().use { conn ->
                conn.createStatement().execute("ALTER TABLE jira_tickets ADD COLUMN status TEXT DEFAULT 'Open'")
            }
        }

        // Check if severity column exists
        var hasSeverity = false
        getConnection().use { conn ->
            conn.createStatement().executeQuery(checkStatus).use { rs ->
                while (rs.next()) {
                    if (rs.getString("name") == "severity") {
                        hasSeverity = true
                        break
                    }
                }
            }
        }

        if (!hasSeverity) {
            getConnection().use { conn ->
                conn.createStatement().execute("ALTER TABLE jira_tickets ADD COLUMN severity TEXT DEFAULT 'Major'")
            }
        }

        // Check if resolved_at column exists
        var hasResolvedAt = false
        getConnection().use { conn ->
            conn.createStatement().executeQuery(checkStatus).use { rs ->
                while (rs.next()) {
                    if (rs.getString("name") == "resolved_at") {
                        hasResolvedAt = true
                        break
                    }
                }
            }
        }

        if (!hasResolvedAt) {
            getConnection().use { conn ->
                conn.createStatement().execute("ALTER TABLE jira_tickets ADD COLUMN resolved_at DATETIME")
            }
        }
    }

    private fun escapeCsv(value: String?): String {
        if (value == null) return ""
        return if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            "\"${value.replace("\"", "\"\"")}\""
        } else {
            value
        }
    }

    private fun getConnection(): Connection {
        Class.forName("org.sqlite.JDBC")
        return DriverManager.getConnection("jdbc:sqlite:$databasePath")
    }
}

data class JiraTicket(
    val testName: String,
    val jiraKey: String,
    val jiraUrl: String,
    val status: String,
    val severity: String,
    val createdAt: Timestamp,
    val resolvedAt: Timestamp?
)

data class TestFailure(
    val testName: String,
    val errorMessage: String,
    val severity: String?,
    val probableCause: String?,
    val status: String,
    val createdAt: Timestamp
)

data class FailureStats(
    val totalFailures: Int = 0,
    val uniqueTests: Int = 0,
    val criticalPercent: Double = 0.0,
    val majorPercent: Double = 0.0,
    val minorPercent: Double = 0.0,
    val resolvedPercent: Double = 0.0
)

data class AnalyticsStats(
    val totalTests: Int = 0,
    val passedTests: Int = 0,
    val failedTests: Int = 0,
    val successRate: Double = 0.0,
    val ticketsCreated: Int = 0,
    val criticalIssues: Int = 0,
    val avgResolutionTime: String = "N/A",
    val openTickets: Int = 0
)

data class PassFailData(
    val dates: List<String>,
    val passed: List<Int>,
    val failed: List<Int>
)

data class TicketTypeData(
    val labels: List<String>,
    val values: List<Int>
)