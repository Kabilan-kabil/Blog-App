package com.cts.jiraplugin.ui

import com.cts.jiraplugin.auth.OAuthManager
import com.cts.jiraplugin.core.JiraClient
import com.intellij.icons.AllIcons
import com.intellij.openapi.actionSystem.ActionManager
import com.intellij.openapi.actionSystem.ActionToolbar
import com.intellij.openapi.actionSystem.DefaultActionGroup
import com.intellij.openapi.project.Project
import com.intellij.openapi.ui.SimpleToolWindowPanel
import com.intellui.ui.components.JBScrollPane
import com.intellij.ui.table.JBTable
import com.intellij.util.ui.JBUI
import javax.swing.JPanel
import javax.swing.JTabbedPane
import javax.swing.table.DefaultTableModel

class EnhancedPluginPanel(project: Project) : SimpleToolWindowPanel(false, true) {
    private val jiraClient = JiraClient("") // Base URL will be set after OAuth

    init {
        val toolbar = createToolbar()
        setToolbar(toolbar.component)

        // Check if user is authenticated
        OAuthManager.loadTokens()
        if (OAuthManager.getAccessToken() == null) {
            showLoginPrompt()
        } else {
            showContent()
        }
    }

    private fun createToolbar(): ActionToolbar {
        val actionGroup = DefaultActionGroup().apply {
            add(LoginAction())
            add(RefreshAction())
            add(LogoutAction())
        }

        return ActionManager.getInstance().createActionToolbar("JiraPluginToolbar", actionGroup, false)
    }

    private fun showLoginPrompt() {
        val loginPanel = JPanel(BorderLayout()).apply {
            border = JBUI.Borders.empty(20)
            add(JBLabel("<html><center>Please log in to Jira to use the plugin features</center></html>"), BorderLayout.CENTER)
        }

        setContent(loginPanel)
    }

    private fun showContent() {
        val tabbedPane = JTabbedPane()

        // My Tickets tab
        val myTicketsPanel = createMyTicketsPanel()
        tabbedPane.addTab("My Tickets", AllIcons.Debugger.Db_marked, myTicketsPanel)

        // Failures tab
        val failuresPanel = createFailuresPanel()
        tabbedPane.addTab("Failures", AllIcons.Debugger.Db_error, failuresPanel)

        // Analytics tab
        val analyticsPanel = AnalyticsPanel(project)
        tabbedPane.addTab("Analytics", AllIcons.Debugger.Console, analyticsPanel)

        setContent(tabbedPane)

        // Load initial data
        refreshMyTickets()
    }

    private fun createMyTicketsPanel(): JPanel {
        val panel = JPanel(BorderLayout())

        // Create table for my tickets
        val tableModel = DefaultTableModel(arrayOf("Key", "Summary", "Status", "Assignee"), 0)
        val table = JBTable(tableModel)

        panel.add(JBScrollPane(table), BorderLayout.CENTER)

        // Add button panel for actions
        val buttonPanel = JPanel(FlowLayout(FlowLayout.LEFT))
        val assignToSelfButton = JButton("Assign to Me").apply {
            addActionListener {
                val selectedRow = table.selectedRow
                if (selectedRow >= 0) {
                    val issueKey = tableModel.getValueAt(selectedRow, 0) as String
                    jiraClient.assignToSelf(issueKey)
                    refreshMyTickets()
                }
            }
        }
        buttonPanel.add(assignToSelfButton)

        panel.add(buttonPanel, BorderLayout.NORTH)

        return panel
    }

    private fun refreshMyTickets() {
        // Get issues assigned to current user
        val myIssues = jiraClient.searchIssues("assignee = currentUser() ORDER BY updated DESC")

        // Update table model
        val tableModel = DefaultTableModel(arrayOf("Key", "Summary", "Status", "Assignee"), 0)
        myIssues.forEach { issue ->
            tableModel.addRow(arrayOf(issue.key, issue.summary, issue.status, issue.assignee))
        }

        // Find and update the table
        val tabbedPane = content as? JTabbedPane
        val myTicketsPanel = tabbedPane?.getComponentAt(0) as? JPanel
        val scrollPane = myTicketsPanel?.getComponent(0) as? JBScrollPane
        val table = scrollPane?.viewport?.view as? JBTable

        table?.model = tableModel
    }

    // Other methods for failures panel, etc.
}

class LoginAction : AnAction("Login", "Login to Jira", AllIcons.General.User) {
    override fun actionPerformed(e: AnActionEvent) {
        val dialog = LoginDialog()
        dialog.show()
    }
}

class LogoutAction : AnAction("Logout", "Logout from Jira", AllIcons.Actions.Exit) {
    override fun actionPerformed(e: AnActionEvent) {
        OAuthManager.logout()
        // Refresh the panel to show login prompt
        val project = e.project
        val toolWindow = ToolWindowManager.getInstance(project).getToolWindow("Jira Test Failures")
        val content = toolWindow?.contentManager?.selectedContent
        val panel = content?.component as? EnhancedPluginPanel
        panel?.showLoginPrompt()
    }
}