plugins {
    id("org.jetbrains.intellij") version "1.17.0"

    kotlin("jvm") version "1.8.0"
}

group = "com.cts"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    implementation("org.xerial:sqlite-jdbc:3.36.0.3")
    implementation("org.json:json:20230227")
}

intellij {
    version.set("2023.1")
    plugins.set(listOf("java"))
}

tasks {
    patchPluginXml {
        sinceBuild.set("231")
        untilBuild.set("241.*")
    }

    compileKotlin {
        kotlinOptions.jvmTarget = "17"
    }
}