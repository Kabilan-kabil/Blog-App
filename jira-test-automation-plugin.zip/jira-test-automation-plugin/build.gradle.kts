import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import org.jetbrains.kotlin.gradle.dsl.KotlinVersion

plugins {
    id("java")
    // Using Kotlin 2.0.0, which is required for modern IDEs
    kotlin("jvm") version "2.0.0"
    id("org.jetbrains.intellij.platform") version "2.8.0"
    kotlin("plugin.serialization") version "2.0.0"
}

group = "org.example"
version = "1.0-SNAPSHOT"

// Configure repositories for a completely offline build
repositories {
    mavenCentral()
    intellijPlatform {
        localPlatformArtifacts()
    }
}

dependencies {
    intellijPlatform {
        // Using the exact path to your local IntelliJ IDEA installation.
        local("C:/Program Files/JetBrains/IntelliJ IDEA Community Edition 2025.1.1.1")

        bundledPlugin("com.intellij.java")
        testFramework(org.jetbrains.intellij.platform.gradle.TestFrameworkType.Platform)
    }

    implementation("org.xerial:sqlite-jdbc:3.36.0.3")
    implementation("org.json:json:20230227")
}

intellijPlatform {
    pluginConfiguration {
        ideaVersion {
            sinceBuild.set("251")
            untilBuild.set("251.*")
        }
        changeNotes = "Initial version"
    }
}

// Configure Java and Kotlin to use Java 17
tasks.withType<JavaCompile>().configureEach {
    sourceCompatibility = "17"
    targetCompatibility = "17"
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
        // Explicitly set the language and API version to 2.0 to match the IDE
        languageVersion.set(KotlinVersion.KOTLIN_2_0)
        apiVersion.set(KotlinVersion.KOTLIN_2_0)
    }
}
