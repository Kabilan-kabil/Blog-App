
import java.io.File
import java.io.FileOutputStream
import java.security.KeyStore
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

fun main() {
    val hosts = arrayOf(
        "cache-redirector.jetbrains.com",
        "www.jetbrains.com",
        "services.gradle.org",
        "repo.maven.apache.org",
        "plugins.gradle.org"
    )

    val keystoreFile = File(System.getProperty("user.home"), "my_truststore.jks")
    val keystorePassword = "changeit".toCharArray()

    println("Loading keystore from: ${keystoreFile.absolutePath}")
    val ks = KeyStore.getInstance(KeyStore.getDefaultType())
    if (keystoreFile.exists()) {
        keystoreFile.inputStream().use { ks.load(it, keystorePassword) }
    } else {
        ks.load(null, keystorePassword)
    }

    val tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
    tmf.init(ks)
    val defaultTrustManager = tmf.trustManagers[0] as X509TrustManager

    val context = SSLContext.getInstance("TLS")
    context.init(null, arrayOf(defaultTrustManager), null)
    val socketFactory = context.socketFactory

    for (host in hosts) {
        println("\nConnecting to $host...")
        try {
            val socket = socketFactory.createSocket(host, 443)
            socket.use { sock ->
                sock.soTimeout = 10000 // 10 seconds
                val tm = object : X509TrustManager {
                    override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
                    override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {
                        chain.forEachIndexed { i, cert ->
                            val alias = "$host-$i"
                            println(" > Found certificate: ${cert.subjectDN}")
                            if (ks.getCertificateAlias(cert) == null) {
                                ks.setCertificateEntry(alias, cert)
                                println("   >> Added certificate to keystore with alias '$alias'")
                            } else {
                                println("   -- Certificate already exists in keystore.")
                            }
                        }
                    }
                    override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
                }
                val customContext = SSLContext.getInstance("TLS")
                customContext.init(null, arrayOf(tm), null)
                customContext.socketFactory.createSocket(sock, host, sock.port, true).use { it.startHandshake() }
            }
        } catch (e: Exception) {
            println("Could not connect to $host: ${e.message}")
        }
    }

    FileOutputStream(keystoreFile).use { ks.store(it, keystorePassword) }
    println("\nKeystore updated successfully at: ${keystoreFile.absolutePath}")
}
